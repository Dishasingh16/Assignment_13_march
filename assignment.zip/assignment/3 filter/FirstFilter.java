package com.cts.training;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

@WebFilter("/RequestHandlerServlet")
public class FirstFilter implements Filter {

	public FirstFilter() {
	}

	public void destroy() {
	}

	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain)
			throws IOException, ServletException {
		String userName = req.getParameter("un");
		String un1 = userName.toUpperCase();

		if (userName.equals(un1)) {
			chain.doFilter(req, resp);
		} else {

			resp.getWriter().write("<h1>enter in upper case only</h1>");
		}
	}

	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("first init");
	}

}
